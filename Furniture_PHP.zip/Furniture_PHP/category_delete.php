<?php
  error_reporting(1);
  include('connection.php');

  $id = $_GET['id'];
  $image = $_GET['image'];
  //echo $id;

  $query = "DELETE FROM categories WHERE id=$id";
  if ($image) {
    if (file_exists('pj_img/category/' . $image)) {
      unlink('pj_img/category/' . $image);
    }
  }
  $connection->query($query);
  header('location:shop.php');

  ?>
  <!--  -->