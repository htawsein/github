<?php
  error_reporting(1);
  include('connection.php');

  $id = $_GET['id'];
  $image = $_GET['image'];
  //echo $id;

  $query = "DELETE FROM services WHERE id=$id";
  if ($image) {
    if (file_exists('pj_img/service/' . $image)) {
      unlink('pj_img/service/' . $image);
    }
  }
  $connection->query($query);
  header('location:about.php');

  ?>
  <!--  -->