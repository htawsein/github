<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Update</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <!-- Update Blog start  -->
    <?php 
    include('connection.php');
    $id = $_GET['id'];
    //echo $id;
    $query_1 = "SELECT * FROM blog WHERE id=$id";
    $result = $connection->query($query_1);
    $select_data = mysqli_fetch_array($result);

    $name = $_POST['name']; 
    $description = $_POST['description'];  
    $submit = $_POST['submit'];

    $old_image = $select_data['image'];
    $new_image = $_FILES['image']['name'];

  if (isset($submit)) {
    if ($new_image) {
      $image = $new_image;
      if (file_exists('pj_img/blog/' . $old_image)) {
        unlink('pj_img/blog/' . $old_image);
      }
      move_uploaded_file($_FILES['image']['tmp_name'], 'pj_img/blog/' . $image);
    } else {
      $image = $old_image;
    }
    $query_2 = "UPDATE blog SET name='$name',image='$image',description='$description' WHERE id='$id'";
    $connection->query($query_2);
    header('location:blog.php');
  }
  ?>
    
    <div class="register-form">       

        <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Blog Update Form</h3>
            <input type="text" placeholder="Enter your team name" name="name" value="<?php echo $select_data['name']; ?>" class="box" required>           
            <input type="file" name="image" class="box" id="image" >
            <img src="pj_img/blog/<?php echo $select_data['image']; ?>" style="width: 100px;" class="card-img-top" alt="...">     
             
             <textarea class="box" rows="5" name="description" id="description"><?php echo $select_data['description']; ?></textarea>
            <input type="submit" value="Update Now" name="submit" class="btn">
        </form>       
        </div>

           
    </div>

    <!-- Update Blog end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>