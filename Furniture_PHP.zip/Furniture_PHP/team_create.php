<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Create</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <!-- Create teamp start  -->
    <?php include('connection.php');
    $name = $_POST['name'];     
    $image = $_FILES['image']['name'];
    $position = $_POST['position'];

    $submit = $_POST['submit'];
    if (isset($submit)) {
        $query = "INSERT INTO teams(name,image,position) VALUES
        ('$name','$image','$position')";
        $connection->query($query);
        move_uploaded_file($_FILES['image']['tmp_name'], 'pj_img/team/' . $image);
        header('location:team.php');
    }
    ?>
    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Team Create Form</h3>

            <input type="text" placeholder="Enter your team name" name="name" class="box" required>
            <input type="file" name="image" class="box" required>
            <input type="text" placeholder="Enter your postion" name="position" class="box" required>
            <input type="submit" value="Create Now" name="submit" class="btn">
        </form>
    </div>

    <!-- Create Team end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>