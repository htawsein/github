<?php
  error_reporting(1);
  include('connection.php');

  $id = $_GET['id'];
  $image = $_GET['image'];
  //echo $id;

  $query = "DELETE FROM products WHERE id=$id";
  if ($image) {
    if (file_exists('pj_img/product/' . $image)) {
      unlink('pj_img/product/' . $image);
    }
  }
  $connection->query($query);
  header('location:shop.php');

  ?>
  <!--  -->