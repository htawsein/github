<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Create</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <!-- Create Product start  -->
    <?php include('connection.php');
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $image = $_FILES['image']['name'];
    $description = $_POST['description'];

    $submit = $_POST['submit'];
    if (isset($submit)) {
        $query = "INSERT INTO products(name,price,quantity,image,description) VALUES
        ('$name','$price','$quantity','$image','$description')";
        $connection->query($query);
        move_uploaded_file($_FILES['image']['tmp_name'], 'pj_img/product/' . $image);
        header('location:shop.php');
    }
    ?>
    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Product Create Form</h3>

            <input type="text" placeholder="Enter your product name" name="name" class="box" required>
            <input type="number" placeholder="Enter your price" name="price" class="box" required>
            <input type="number" placeholder="Enter your quantity" name="quantity" class="box" required>
            <input type="file" name="image" class="box" required>
            <textarea class="box" rows="5" name="description" id="description" required placeholder="Enter your description"></textarea>
            <input type="submit" value="Create Now" name="submit" class="btn">
        </form>
    </div>

    <!-- Create Product end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>