<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="icon" href="image/favicon.ico">
    <?php include('css.php'); ?>
</head>

<body>

    <?php include('connection.php'); ?>

    <?php include('header.php'); ?>

    <?php include('navbar.php'); ?>

    <!-- home section starts  -->

    <section class="home">
        <div class="slides-container">

            <div class="slide active">
                <div class="content">
                    <span>new arrivals</span>
                    <h3>flexible chair</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia eveniet officia tempore accusantium perspiciatis magnam, esse, iure quisquam, harum beatae ab. Velit iure ullam quis rem excepturi quasi reiciendis beatae!</p>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="image">
                    <img src="image/home-img-1.png" alt="">
                </div>
            </div>

            <div class="slide">
                <div class="content">
                    <span>new arrivals</span>
                    <h3>flexible chair</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia eveniet officia tempore accusantium perspiciatis magnam, esse, iure quisquam, harum beatae ab. Velit iure ullam quis rem excepturi quasi reiciendis beatae!</p>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="image">
                    <img src="image/home-img-2.png" alt="">
                </div>
            </div>

        </div>

        <div id="slide-next" onclick="next()" class="ri-arrow-right-line"></div>
        <div id="slide-prev" onclick="prev()" class="ri-arrow-left-line"></div>
    </section>

    <!-- home section ends -->


    <!-- banner section starts  -->
    <section class="products">
    <h1 class="title"> <span>our promotion Items</span> <button onclick="window.location.href='promotion_create.php'" class="btn title-btn">Add new promotion</button></h1>

    <section class="banner-container">  

    <?php
      error_reporting(1);
      include('connection.php');
      $query = "SELECT * FROM promotions ORDER BY id DESC";
      $rowdata = $connection->query($query);
      while (list($id, $name, $discount,$image) = mysqli_fetch_array($rowdata)) {

      ?>
        <div class="banner">
            <img src="pj_img/promotion/<?php echo $image; ?>" alt="">
            <div class="content">
                <span><?php echo $name; ?></span>
                <h3><?php echo $discount; ?></h3>
                <a href="#" class="btn">shop now</a>
               <h1 class="title service">
                        <a href='promotion_update.php?id=<?php echo $id; ?>'" class="btn title-btn">Update </a>
                        <a href='promotion_delete.php?id=<?php echo $id; ?>&image=<?php echo $image; ?>'" class="btn title-btn">Delete </a>
                </h1>
            </div>
        </div>

        <?php } ?>

        <div class="banner">
            <img src="image/banner-2.jpg" alt="">
            <div class="content">
                <span>limited offer</span>
                <h3>upto 50% off</h3>
                <a href="#" class="btn">shop now</a>
            </div>
        </div>

        <div class="banner">
            <img src="image/banner-3.jpg" alt="">
            <div class="content">
                <span>limited offer</span>
                <h3>upto 50% off</h3>
                <a href="#" class="btn">shop now</a>
            </div>
        </div>

        <div class="banner">
            <img src="image/banner-3.jpg" alt="">
            <div class="content">
                <span>limited offer</span>
                <h3>upto 50% off</h3>
                <a href="#" class="btn">shop now</a>
            </div>
        </div>

    </section>
</section>

    <!-- banner section ends -->

    <?php include('footer.php'); ?>

    <?php include('js.php'); ?>

</body>

</html>