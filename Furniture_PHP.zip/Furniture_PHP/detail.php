<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <?php include('css.php'); ?>

</head>

<body>
    <?php
    // session_start();

    // if (!isset($_SESSION['username'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    ?>

    <?php include('connection.php'); ?>

    <?php include('header.php'); ?>

    <?php include('navbar.php'); ?>

    <!-- heading section start -->

    <section class="heading">
        <h3>our shop</h3>
        <p><a href="index.php">home</a> / <span>about</span></p>
    </section>

    <!-- heading section end -->



    <!-- detail section start -->
    <?php
      error_reporting(1);
      include('connection.php');
      $id = $_GET['id'];

      $query1 = "SELECT * FROM products WHERE id=$id";
      $result1 = $connection->query($query1);
      $select_data = mysqli_fetch_array($result1);
    ?>

    <section class="about">

        <div class="image">
            <img src="pj_img/product/<?php echo $select_data['image']; ?>" alt="">
        </div>

        <div class="content">            
            <h3><?php echo $select_data['name']; ?></h3>
            <span>$<?php echo $select_data['price']; ?></span>
            <p><?php echo $select_data['description']; ?></p>
        </div>

    </section>

    <!-- about detail end -->


    <!-- Details section start -->

    <section class="services">

        <h1 class="title"> 
            <span>our services</span> 
            <a href="#">view all >></a>
            <a href="service_create.php" class="btn title-btn">Add new service</a>
        </h1>

        <div class="box-container">
        <?php
      error_reporting(1);
      include('connection.php');
      $query = "SELECT * FROM services ORDER BY id DESC";
      $rowdata = $connection->query($query);
      while (list($id, $name, $image,  $description) = mysqli_fetch_array($rowdata)) {

      ?>
            <div class="box">
                <img src="pj_img/service/<?php echo $image; ?>" alt="">
                <h3><?php echo $name; ?></h3>
                <p><?php echo $description; ?></p>
                <a href="#" class="btn">read more</a>
            </div>
            <?php } ?>
            <div class="box">
                <img src="image/serv-2.png" alt="">
                <h3>product designing</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus id necessitatibus atque quod dicta. Esse perferendis sit vel quam deleniti voluptate. Provident molestias quibusdam recusandae quas illum ratione natus hic.</p>
                <a href="#" class="btn">read more</a>
            </div>

            <div class="box">
                <img src="image/serv-3.png" alt="">
                <h3>24 / 7 support</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus id necessitatibus atque quod dicta. Esse perferendis sit vel quam deleniti voluptate. Provident molestias quibusdam recusandae quas illum ratione natus hic.</p>
                <a href="#" class="btn">read more</a>
            </div>

        </div>

    </section>

    <!-- Details section end -->






    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>