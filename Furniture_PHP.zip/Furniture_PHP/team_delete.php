<?php
  error_reporting(1);
  include('connection.php');

  $id = $_GET['id'];
  $image = $_GET['image'];
  //echo $id;

  $query = "DELETE FROM teams WHERE id=$id";
  if ($image) {
    if (file_exists('pj_img/team/' . $image)) {
      unlink('pj_img/team/' . $image);
    }
  }
  $connection->query($query);
  header('location:team.php');

  ?>
  <!--  -->