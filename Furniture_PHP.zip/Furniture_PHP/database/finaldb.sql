-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 11, 2025 at 06:56 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `name`, `image`, `description`) VALUES
(1, 'Blog about Modern Accent Chairs', 'blog-1.jpg', 'Modern Accent Chair with Wood Frame, Upholstered Living Room Chairs with Waist Cushion, Reading Armchair for Bedroom Sunroom (Beige).Modern Accent Chair with Wood Frame.'),
(2, 'Blog About Modern living room ', 'modern living room furniture.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed minus, iusto quasi laboriosam voluptatibus at esse maxime quod quae mollitia molestiae magnam aperiam aspernatur eius obcaecati enim eveniet quis fugit!Enter your description'),
(3, 'Blog About kitchen room furniture', 'modern kitchen room furniture.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed minus, iusto quasi laboriosam voluptatibus at esse maxime quod quae mollitia molestiae magnam aperiam aspernatur eius obcaecati enim eveniet quis fugit!Enter your description'),
(5, 'Blog About Modern Sofa', 'blog-6.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed minus, iusto quasi laboriosam voluptatibus at esse maxime quod quae mollitia molestiae magnam aperiam aspernatur eius obcaecati enim eveniet quis fugit!Enter your description');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`) VALUES
(1, 'Living Room Furniture', 'livingroom-furniture.png'),
(2, 'Bed Furniture Purple', 'bed.png'),
(3, 'Table Orange New', 'Coffee Tables.png'),
(4, 'Dining Room Furniture', 'diningroom_table.png'),
(5, 'Modern Sofa High Quality', 'home-img-2.png'),
(6, 'Modern Table Good', 'icon-2.png'),
(7, 'Office Chair New', 'icon-4.png');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone_number` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `phone_number`, `email`, `message`) VALUES
(1, 'Htaw Sein', 402562957, 'mahtawsein.lmt@gmail.com', 'I want to order for dining room table.'),
(2, 'Bezaleel Ro', 402562957, 'bezaleelro.2015@gmail.com', 'I want to order for reading table.'),
(3, 'Htaw Sein', 402562957, 'mahtawsein.lmt@gmail.com', 'I want to know about furniture.'),
(4, '', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `quantity` int NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `quantity`, `image`, `description`) VALUES
(1, 'Wade 3 Seater Fabric Sofa - Furniture Village', 1000, 10, 'Wade 3 Seater Fabric Sofa.png', 'Our Wade range delivers power comfort that fits in any size of living room. With wall-away power recliners and adjustable headrests, the collection of space-saving sofas and armchair help you find your perfect relaxed position – and sit neatly against a living room wall'),
(2, 'Liverpool Living Room - Sofa - Table - Armchair', 5000, 10, 'Liverpool Living Room.jpg', 'The living room is the most important part of your home. We should decorate this room with something different and elegant. This is why we bring you a wide selection of furniture with the best quality, which offers an easy way to make your living rooms more exclusive and elegant. Our products are not only designed for luxury; they are ideal for comfort and functionality as well.'),
(3, 'Coffee Tables - Round & Rectangle - Furniture', 2500, 8, 'Coffee Tables - Round & Rectangle - Furniture Village.png', 'All the high-end style of marble furniture, all the family-friendly durability of ceramic, and all at a great-value price – our Avorio range makes it easy to furnish living and dining spaces in glossy ceramic style. The collection includes both fixed and extending dining tables'),
(4, 'classic mid century modern dining room ', 2000, 10, 'Classic Wooden Dining Table.jpg', 'This classic mid-century modern dining room is a dream! From the clean furniture to the earthy colors, everything feels cozy and stylish. So pretty – it makes every meal feel special. Classic. Clean. Chic. This mid-century modern dining room is simply beautiful – so pretty and perfectly balanced! Love mid-century vibes? This classic dining room brings out the beauty of minimal design with a soft, pretty touch. SoPretty MidCenturyMagic');

-- --------------------------------------------------------

--
-- Table structure for table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
CREATE TABLE IF NOT EXISTS `promotions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `promotions`
--

INSERT INTO `promotions` (`id`, `name`, `discount`, `image`) VALUES
(2, 'Limited Offer', 'Up to 30%', 'banner-3.jpg'),
(3, 'Limited Offer', 'Up to 20%', 'banner-2.jpg'),
(4, 'Limited Offer', 'Up to 40%', 'banner-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `image`, `description`) VALUES
(1, 'Furniture Assembly Service', 'serv-2.png', 'A perfect-fit sofa, a unique coffee table, or a custom-built wardrobe, our design team will work closely with you to create furniture that matches your space, lifestyle.'),
(2, 'Fast & Reliable Delivery', 'serv-3.png', 'We know waiting is not fun. That is why we provide fast, safe, and on-time delivery across the country. You’ll get real-time tracking and professional handling to ensure your furniture arrives in perfect condition.'),
(3, 'Furniture Restoration & Repair', 'serv-2.png', 'Our skilled craftsmen can restore or repair your favorite furniture pieces—whether it is a vintage wooden chair or a worn-out sofa. Wood Furniture Repair Illustrations.'),
(4, 'Flexible Payment Options', 'serv-1.png', 'We offer flexible installment plans and easy financing options. Choose the payment plan that suits your budget—no stress, no delays. Enjoy your dream home today.');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `image`, `position`) VALUES
(2, 'John Smith', 'team-6.jpg', 'Senior Web Engineer'),
(3, 'Diana Smith', 'team-3.jpg', 'Front-End Web Engineer'),
(4, 'Ava Johnson', 'team-4.jpg', ' Full Stack Web Engineer'),
(5, 'Sophia Lin', 'team-1.jpg', 'Web Engineer'),
(6, 'Christina Htwe', 'team-5.jpg', 'Software Developer');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `email`, `password`) VALUES
('htawsein', 'mahtawsein.lmt@gmail.com', '$2y$10$q1RuRCGUEaikZW4aINqC/Oq9B6.TETqx5I6g6X4OXaAHpvaW9s3Yu');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
