<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promotion Create</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <!-- Create Promotion start  -->
    <?php include('connection.php');
    $name = $_POST['name'];  
    $discount = $_POST['discount'];   
    $image = $_FILES['image']['name'];    

    $submit = $_POST['submit'];
    if (isset($submit)) {
        $query = "INSERT INTO promotions(name,discount,image) VALUES
        ('$name','$discount','$image')";
        $connection->query($query);
        move_uploaded_file($_FILES['image']['tmp_name'], 'pj_img/promotion/' . $image);
        header('location:index.php');
    }
    ?>
    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Promotion Create Form</h3>

            <input type="text" placeholder="Enter your promotion name" name="name" class="box" required>
            <input type="text" placeholder="Enter your discount" name="discount" class="box" required>
            <input type="file" name="image" class="box" required>           
            <input type="submit" value="Create Now" name="submit" class="btn">
        </form>
    </div>

    <!-- Create Promotion end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>